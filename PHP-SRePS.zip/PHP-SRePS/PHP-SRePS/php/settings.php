<?php
	//Database Settings used for PHP-SRePS

	$host = "localhost";  //server
	$user = "root";  //username
	$pwd = "";  //password
	$sql_db = "php_SRePS"; //database
?>
